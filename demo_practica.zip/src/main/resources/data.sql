insert into student
values(10001,'ranga', 'e1234567');

insert into student
values(10002,'ravi', 'a1234568');